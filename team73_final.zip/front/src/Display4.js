import React from 'react';

const Display4 = () => {
  return (
    <div>

    </div>  
  );
};

export default Display4;