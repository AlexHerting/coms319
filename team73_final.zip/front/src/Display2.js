import React from 'react';

const Display2 = () => {
  return (

<div></div>
  );
};

export default Display2;