import React from 'react';

const Display3 = () => {
  return (
    <div>

    </div>  
  );
};

export default Display3;