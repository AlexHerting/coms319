import React from 'react';

const Credits = () => {
    return (
      <div>
        <h1>Credits</h1>
        <p><br></br></p>
        <h4>SE/COMS 319 - Construction of User Interfaces</h4>
        <h4>Professor: Dr. Abraham Aldaco</h4>
        <h4>Date: April 30th, 2023</h4>
        <p><br></br></p>
        <h4>Student 1: Alex Herting - aherting@iastate.edu</h4>
        <h4>Student 2: Ter Xun Ng - terxun@iastate.edu</h4>
        <p><br></br></p>
        <h4>Introduction:</h4>
        <p>This is phase 2 of the final project. We use get, put, delete, and post methods in the backend to make this project function <br></br> We have also decided to use mongo db as we are much more familiar and comfortable with using it. <br></br>You will notice that we have some unused displays, these are for the final project and were not necesarry for this phase.
        </p>
      </div>
      
    );
  };
  
  export default Credits;